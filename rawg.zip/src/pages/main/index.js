import React from 'react';

import './style.css';

export default function Main(){
    return (
        <main id="main-page">
            <nav id="navtop">
                <a href="#!" >L1</a>
                <a href="#!" >Store</a>
                <a href="#!" >My games</a>
                <a href="#!" >Media</a>
                <a href="#!" >Library</a>
                <a href="#!" >Settings</a>
                <a href="#!" >R1</a>
            </nav>

            <section id="all-games">
                <ul id="game-list">
                    <li className="game-item">
                        <img src="https://media.rawg.io/media/crop/600/400/games/bc7/bc7e583a6e4ceec38f0557cf8910da1f.jpg" alt="card"/>
                    </li>

                    <li className="game-item">
                        <img src="https://media.rawg.io/media/crop/600/400/games/bc7/bc7e583a6e4ceec38f0557cf8910da1f.jpg" alt="card"/>
                    </li>

                    <li className="game-item">
                        <img src="https://media.rawg.io/media/crop/600/400/games/bc7/bc7e583a6e4ceec38f0557cf8910da1f.jpg" alt="card"/>
                    </li>

                    <li className="game-item">
                        <img src="https://media.rawg.io/media/crop/600/400/games/bc7/bc7e583a6e4ceec38f0557cf8910da1f.jpg" alt="card"/>
                    </li>

                    <li className="game-item">
                        <img src="https://media.rawg.io/media/crop/600/400/games/bc7/bc7e583a6e4ceec38f0557cf8910da1f.jpg" alt="card"/>
                    </li>

                    <li className="game-item">
                        <img src="https://media.rawg.io/media/crop/600/400/games/bc7/bc7e583a6e4ceec38f0557cf8910da1f.jpg" alt="card"/>
                    </li>

                    <li className="game-item">
                        <img src="https://media.rawg.io/media/crop/600/400/games/bc7/bc7e583a6e4ceec38f0557cf8910da1f.jpg" alt="card"/>
                    </li>
                </ul>

                <article className="game-info-preview">
                    <h1>the last of us II</h1>
                    <div className="subinfo r-date">
                        <p>Release Date:</p>
                        <p>Jun 19, 2020</p>
                    </div>
                    <div className="subinfo g-genre">
                        <p>Genre:</p>
                        <p>Action, Shooter, Adventure</p>
                    </div>
                    <div className="subinfo g-meta">
                        <p>Metacritic:</p>
                        <p>98</p>
                    </div>
                </article>
            </section>
            
        </main>
    );
}